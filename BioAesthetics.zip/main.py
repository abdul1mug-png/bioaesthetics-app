"""
BioAesthetic — FastAPI Application Entry Point
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import time
import logging

from app.config import settings
from app.database import init_db

# ── Routers (imported lazily to avoid circular deps) ──────────────────────────
from routes import auth_router, skin_router, physique_router, hormone_router, dashboard_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ── App Factory ───────────────────────────────────────────────────────────────
def create_app() -> FastAPI:
    app = FastAPI(
        title="BioAesthetic API",
        version="1.0.0",
        description="Biometric optimization platform — skin, physique, hormone & youth index scoring.",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Trusted hosts (prod hardening)
    if settings.ENV == "production":
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=settings.ALLOWED_HOSTS)

    # Request timing middleware
    @app.middleware("http")
    async def add_process_time_header(request: Request, call_next):
        start = time.perf_counter()
        response = await call_next(request)
        elapsed = (time.perf_counter() - start) * 1000
        response.headers["X-Process-Time-Ms"] = f"{elapsed:.2f}"
        if elapsed > 300:
            log.warning(f"Slow response: {request.url.path} took {elapsed:.0f}ms")
        return response

    # Global exception handler
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        log.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(status_code=500, content={"detail": "Internal server error"})

    # Routers
    app.include_router(auth_router, prefix="/auth", tags=["Auth"])
    app.include_router(skin_router, prefix="/skin", tags=["Skin"])
    app.include_router(physique_router, prefix="/physique", tags=["Physique"])
    app.include_router(hormone_router, prefix="/hormone", tags=["Hormone"])
    app.include_router(dashboard_router, prefix="/dashboard", tags=["Dashboard"])

    # Lifecycle
    @app.on_event("startup")
    async def startup():
        log.info("BioAesthetic API starting up...")
        await init_db()
        log.info("Database initialized.")

    @app.get("/health", tags=["Health"])
    async def health_check():
        return {"status": "ok", "version": "1.0.0"}

    return app


app = create_app()
